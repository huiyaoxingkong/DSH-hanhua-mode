# DSH-hanhua-mode · 汉化模式

面向 DSH（DeepSeek Harness）的游戏汉化专家模式：扫描、解析、术语词典翻译、在线 API 兜底、QA 质检、按原格式/原编码二进制回写，一条龙完成游戏汉化。

## 支持的引擎与格式

| 引擎 | 文件格式 | 说明 |
| --- | --- | --- |
| 通用文本 | JSON / CSV / TSV / PO / INI / TXT / YAML / RenPy | 通用结构解析，按路径/行列/行回写 |
| RPG Maker MV / MZ | `data/*.json`、`Map*.json`、`System.json`、`CommonEvents.json` | 地图事件对话(101/401)、选项(102/402)、注释(408)、数据库条目、System 术语 |
| RPG Maker XP / VX / VX Ace / mkxp-z（RGSS 家族） | `.rxdata` / `.rvdata` / `.rvdata2`（Ruby Marshal 4.8） | 纯 JS 实现的 Marshal 读取/写回（保留符号/对象/链接结构），地图事件、数据库、System 术语、公共事件；`Scripts.*` 自动跳过 |
| krkr / KAG（KiriKiri） | `.ks` / `.tjs` / `.scn` / `.csv` / `.txt` | 自动识别 UTF-16LE(BOM)/UTF-16BE/UTF-8/Shift-JIS/GBK；标签属性(`text=`/`name=`/`title=` 等)与裸文本行提取；按原编码回写 |

## 安装（DSH 预设）

1. 打开 DSH 用户预设根目录：`${DSH_HOME:-~/.dsh}/.agent-presets/`
2. 把本仓库的 `preset/` 目录复制为 `<预设根>/hanhua/`（即 `agent.cordis.yml` 与 `preset.yml` 位于该目录下）
3. 新建会话时选择「**汉化模式**」预设即可；重启后功能依然可用

> `preset/agent.cordis.yml` 中挂载了本地插件包：`name: ./plugins/hanhua/index.js`（相对预设目录解析）。插件消费 host 的 `tools/systemPrompt/fs/web/sandboxPolicy/subprocess` 服务，不提供任何服务，无需 isolate realm。

## 内核版本兼容

| 内核 | 状态 | 说明 |
| --- | --- | --- |
| `dsh 0.1.6-alpha.2`（桌面封装 1.0.5 随包） | ✅ 已适配并验证 | 组合文件由新版随包 standard 派生（persona 用 `prefix`/`suffix`、`workflow-ptc`、`present`、`command-goal` 等）；插件补了 `subprocess.spawn` 的 `cwd`、提示片段 `order` 档位与 iconv 解析 |
| `dsh 0.1.1-rc.2` 及更早 | ⚠️ 未回归验证 | 本仓库在 0.1.6 上做的改动（补 `cwd`、`order` 档位）对旧内核同样合法，但组合文件已随新版 standard 对齐，旧内核上未再实测 |

升级到 0.1.6 时踩到的两类坑（**一行配置坏 → 整份预设挂载失败**、`subprocess.spawn` 缺 `cwd` 会让所有写回失败）与修复细节见 [适配修复报告](docs/UPGRADE-0.1.6-alpha.2.md)。审计与验证材料：

- [主机 API 兼容性审计（0.1.1-rc.2 → 0.1.6-alpha.2）](docs/COMPAT-0.1.6-alpha.2.md)
- [客户端半/动态插件审计](docs/CLIENT-COMPAT-0.1.6-alpha.2.md)
- [独立验证报告](docs/VERIFY-0.1.6-alpha.2.md)
- [汉化工作台装载与使用（0.1.6）](docs/WORKBENCH-0.1.6.md)

自检与回归测试（用桌面封装内置 Node：`<安装目录>\runtime\node.exe`）：

```powershell
node tests\mount-check.mjs            # 组合文件「挂载级」检查：行解析 + 每行 Config 校验
node tests\preset-health.mjs          # 真实 discovery 健康检查（预设选择器口径）
node tests\harness.mjs                # 真实 0.1.6 服务实现下跑通 scan→parse→translate→qa→export
node tests\build-composition.mjs --check   # 组合文件是否仍等于「新版标准 + 汉化行」的派生结果
```


## 工作流

```
hanhua_scan 扫描项目
  → hanhua_parse 提取全部文本（errors 字段列出失败文件）
  → hanhua_glossary 维护术语词典（人名/地名/道具名必须统一）
  → hanhua_translate 翻译（词典优先，可选在线 API 兜底）
  → hanhua_qa 质检（占位符/换行/长度/漏译）
  → hanhua_export 写回（inplace 自动 .bak 备份 / out 输出镜像目录）
```

浏览器面板（**设置 →「汉化工作台」**）是同一套引擎的第二入口：先在会话里执行 `hanhua_workbench action=install`
装载动态包，再到 Cordis 面板点「仅允许此版本」；步骤、生命周期与排错见 [装载与使用说明](docs/WORKBENCH-0.1.6.md)。

## 配置（hanhua_config）

| 字段 | 说明 |
| --- | --- |
| `root` | 项目根目录（游戏目录） |
| `apiUrl` / `apiKey` / `model` | OpenAI 兼容 chat/completions 接口，用于词典未覆盖文本的在线翻译 |
| `targetLang` / `sourceLang` | 目标/源语言 |
| `rgssEncoding` | RGSS 字符串编码（`auto`/`utf-8`/`gbk`/`shift_jis`），默认 `auto` |
| `krkrEncoding` | krkr 文本编码，默认 `auto` |
| `iconvPath` | iconv-lite 绝对路径，用于 GBK/Shift-JIS 写回；不设置时尝试 node 全局解析 |
| `apiChunk` | 在线 API 每批条数（默认 40，范围 1-100）；越大越省提示词开销 |

## Token 优化

在保证翻译符合语境的前提下尽量少消耗 token（在线 API token 与对话上下文 token）：

- **智能过滤**：无字母（纯数字/符号）或中日韩字符占比 ≥ 50% 的条目直接跳过（method=`skip`），不产生 API 调用
- **语境去重**：相同原文 + 相同语境只翻译一次，其余条目复用首条译文
- **语境标签压缩提示词**：API 请求按紧凑的 `[语境, 原文]` 对发送（名称/选项/地图对话/剧本对话/系统术语等）
- **分批**：按 `apiChunk` 分批调用，单次提示词开销可控
- **紧凑预览**：`hanhua_parse`/`hanhua_translate` 只返回 ≤20 条预览 + perFile 统计，翻译预览仅含有实际变更的条目，节省对话上下文

## 目录结构

```
DSH-hanhua-mode/
├── engine/          # 动态插件（工作台）源码成品
│   ├── host.js      # 引擎主体（解析/翻译/QA/导出/Marshal/krkr）
│   └── client.js    # 浏览器「汉化工作台」面板（常驻设置页）
├── preset/          # 「汉化模式」持久化预设成品（复制到 .agent-presets/hanhua）
│   ├── agent.cordis.yml
│   ├── preset.yml
│   └── plugins/hanhua/{package.json,index.js,engine/{host.js,client.js}}
├── tests/           # 自检与回归测试（挂载级检查 / 真实运行时集成测试 / 组合文件生成器）
├── fixtures/        # 测试夹具生成器与调试脚本
├── docs/            # 使用手册、兼容性审计与验证报告
└── release/         # 成品压缩包
```

## 已知限制

- RGSS `Scripts.rxdata` 脚本代码不处理（仅跳过）；加密/改造过的 Marshal 数据可能无法解析（errors 会报告）。
- `.xp3` 打包的 krkr 资源需先用外部工具解包。
- GBK/Shift-JIS 写回依赖 iconv-lite（node 子进程）；插件会依次尝试 `iconvPath`、`%DSH_HOME%/profiles{,/web}/node_modules/iconv-lite` 与全局 `iconv-lite`，都不可用时该文件的导出会报错（不再静默失败）。
- **目标编码容纳不了中文时会被替换成 `?`**：Shift-JIS/GBK 里没有的汉字（例如把简体中文写进 Shift-JIS 文件）由 iconv 兜底替换；这类游戏请把 `rgssEncoding`/`krkrEncoding` 设为 `utf-8`（或以原编码输出再另行转换）。
- 在线翻译 API 兜底不可用：DSH 的 `ctx.web.fetch` 只接受 `url` 且 provider 硬编码 GET，插件发出的 POST 请求体不会被发送（新旧内核皆然）；词典/缓存路径不受影响。
- 「汉化工作台」浏览器面板（常驻 **设置 →「汉化工作台」**）需按 [装载与使用说明](docs/WORKBENCH-0.1.6.md) 自行装载：会话里执行 `hanhua_workbench action=install`，再到 Cordis 面板点「仅允许此版本」。定义是进程内状态，DSH 重启或浏览器页面刷新后需重新装载；会话流里的「快捷面板」已随 `cordis_run` 卡片退役而删除（`tool.view.cordis` 没有渲染位）。静态 `hanhua_*` 工具不受影响。
- 导出时会在项目根留下两个临时文件 `.hanhua-iconv.in.json` / `.hanhua-iconv.bin`（iconv 批量编码的输入输出，已被扫描/解析忽略，可随时手动删除）。
- `.bak` 是**写一次即固定**的「汉化前原文」回滚点：重复导出不会刷新它。若要回滚到某一轮之前的状态，请改用版本控制或 `pristine-snapshot`。
- RGSS 字符串按 `rgssEncoding` 配置统一解码，同一游戏混用多种编码时建议逐文件处理。


## License

MIT
