# 动态插件源码说明

本目录是「游戏汉化引擎」动态 Cordis 插件（`hanhu-1`）的源码成品，两半可以整体粘贴到 `cordis_define` 的 `code.host` / `code.client` 中运行。

- `host.js` — Host 半：引擎主体。函数体形式（`return { apply(ctx) {...} }`），运行在 DSH 宿主进程。
  - 模块：扫描（适配器注册表）→ 解析（JSON/CSV/PO/INI/TXT/YAML/RenPy + RPG Maker MV/MZ + RGSS Marshal + krkr）→ 翻译（词典优先/缓存/在线 API）→ QA → 导出（按格式重建 + 字节级写回）。
  - token 优化：语境标签（`ctxTagOf`）压缩 API 提示词；无字母/高 CJK 条目跳过（method=`skip`）；原文+语境去重；`apiChunk` 分批（默认 40）；parse/translate 只返回 ≤20 条紧凑预览 + perFile 统计。
  - 依赖服务：`fs`、`web`、`sandboxPolicy`、`subprocess`（均 `ctx.get` 可选获取，缺失时给出明确错误）。
  - 会话工作区：从工具执行上下文 `exec.agent.session.header.cwd` 获取；写入时携带 `sandboxPolicy.resolve({session})`。
  - 二进制写盘：自实现 base64 编码器 + node 子进程 `writeFileSync`（沙箱 `btoa` 是 UTF-8 语义，不能用于二进制）。
  - GBK/Shift-JIS 编码：node 子进程 + iconv-lite（路径可配置 `iconvPath`）。
- `client.js` — Client 半：浏览器「汉化工作台」。无 JSX，全部 `React.createElement`。
  - 注册 `settings.section`（id=`hanhua-workbench`）整页面板与 `tool.view.cordis`（key=`self`）运行卡快捷面板。
  - 通过 `host.call('workbench.*')` 与 Host 半通信。

## 版本演进（重要修复备忘）

1. 工具输出 schema 必须是 `{type:'json'}`（`string` 会拒绝结构化返回值）。
2. `FsDirEntry.type` 的值是 `'directory'`（不是 `'dir'`）。
3. 会话工作区必须取 `exec.agent.session.header.cwd`（宿主级 `sandboxPolicy.workspaceRoot` 是进程工作目录）。
4. 写盘必须传 `sandboxPolicy.resolve({session})`，否则写不进会话工作区。
5. `parseFiles` 的 `root` 参数校验后要赋值给 `state.root`。
6. Marshal：文件头 `04 08` 要跳过/写出；`o/u/U/e/S/I` 的类名与 ivar 键是带 `0x3A` 前缀的符号（`readSym`），不能直接 `readName`。
7. 沙箱 `btoa` = UTF-8 编码后 base64；二进制必须用自实现 `bytesToB64`。
8. krkr 引号属性值切片：值域是 `[start+1, end)`，替换后剩余从 `end+1` 开始。
9. `subprocess.spawn` 必须带 `graceMs`。
10. token 优化（v8/v11）：语境标签/智能过滤（skip）/同语境去重/`apiChunk` 分批/紧凑预览（≤20 条）；QA 对 `skip` 条目静默。

### v12 · 适配 DSH 0.1.6-alpha.2（桌面封装 1.0.5）

11. **`subprocess.spawn` 必须带 `cwd`**：0.1.6 的 `LocalSubprocessRuntime.spawn()` 先调 `targetEnvironment(spec)`，对 `spec.cwd` 调 `validateNoNullByte` → 缺省即 `undefined.includes('\0')` 抛 `TypeError`；旧版容忍缺省。两半（静态预设与动态）共 4 个调用点全部改为 `cwd: spawnCwd()`（项目根，缺省 `.`）。`SubprocessSpawnSpec.cwd` 在新旧两版都是必填字符串，故该改动向后兼容。
12. **提示片段 `order` 改用 0.1.6 的中央档位**：`order: 115 → 3200`（旧约定「工具指南 100–199」已失效；新档位：persona 0 / plan 500 / 工具指南 1000–3100 / TOOLS_SDK 5000 / persona 后缀 10200）。
13. **iconv-lite 解析加固**：`node -e` 的 `require()` 从**子进程 cwd** 向上找 `node_modules`，而 cwd 是游戏目录 → 旧的单点 `require('iconv-lite')` 以 `code=3` 静默失败，GBK/Shift-JIS 回写全灭。现按 `config.iconvPath` → `%DSH_HOME%/profiles{,/web}/node_modules/iconv-lite` → 全局 的顺序给候选清单，并把候选 `node_modules` 目录并入子进程 `NODE_PATH`。
14. **组合文件层面（不属于本文件）**：0.1.6 的 `@deepseek-ai/dsh-persona` 把必填配置从 `text` 改成 `prefix`（+可选 `suffix`）；`workflow-worker-thread` 在本机 profile 里仍是旧版、在 0.1.6 下 import 失败。`preset/agent.cordis.yml` 因此改为由新版随包 standard 派生（见 `tests/build-composition.mjs` 与 [适配修复报告](../docs/UPGRADE-0.1.6-alpha.2.md)）。

> 自检：`node ../tests/harness.mjs`（真实 0.1.6 服务实现下跑通全流程）。

### v12/v9 · 工作台自装（0.1.6 没有模型工具能创建动态包了）

15. **动态半只做「汉化工作台」**：`cordis_define/cordis_run` 已退役，动态包改由预设插件自装（工具 `hanhua_workbench`，见 `../docs/WORKBENCH-0.1.6.md`）。因此 `host.js` 末尾**停用了** `harness.registerTool` 循环：动态包的注册落在**全局层**，会让同进程其他会话也看到 7 个 `hanhua_*` 工具。`workbench.*` RPC 处理器不受影响，模型侧工具始终由预设插件（agent 层）提供 8 个。
16. **client 半 v9**：删掉 `tool.view.cordis`（key='self'）注册与 `QuickPanel` —— 它的渲染位挂在 `cordis_run` 卡片上，卡片退役后永远不显示；只保留 `settings.section` 常驻设置页。
17. **预设自包含**：`preset/plugins/hanhua/engine/{host.js,client.js}` 是 `engine/` 两份源码的逐字节副本（`Copy-Item` 同步，改动后必须重新复制），插件用 `import.meta.url` 推导自身目录读取它们。


## 与预设版的关系

`../preset/plugins/hanhua/index.js` 是同一引擎的**静态插件版**（ESM 导出 `name/inject/apply`，`ctx.tools.register` 注册工具、返回 JSON 字符串、注入 `subprocess/sandboxPolicy`），供「汉化模式」预设永久挂载。两份源码需同步演进。
