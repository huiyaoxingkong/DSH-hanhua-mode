# 安装（v2.1.0）

## 桌面版（0.2.0-rc.2）

把本包解压出的 `preset/plugins/hanhua/` 整个目录复制到 `<DSH_HOME>/hanhua/plugins/hanhua/`，
或用仓库里的安装脚本（推荐，会同时写预设声明并校验）：

```powershell
node tools\install-hanhua-desktop.mjs --home <DSH_HOME>
node tools\validate-declaration.mjs "<DSH_HOME>\hanhua\cordis.patch.yml"
```

重启 DSH 后，新建会话的预设列表里会出现「汉化模式」。

## 旧内核（0.1.6-alpha.2）目录式预设

把本包的 `preset/` 目录复制为 `<DSH_HOME>/.agent-presets/hanhua/`，新建会话选择「汉化模式」。
